<?php

	class topicBlog extends Controller{
		public function __construct(){
			parent::__construct();
			$id = isset($_GET["id"])?$_GET["id"]:"";
            $number = $this->Model->count("select * from menu_list_blog where catalog='$id'");
			$num_page = 4;
			$page_show = ceil($number/$num_page);
			$page = isset($_GET["p"])&&$_GET["p"]>0?$_GET["p"]:1;
			$form = ($page-1)*$num_page;

			
			$value1 = $this->Model->fetch("select * from menu_list_blog where catalog='$id' limit $form,$num_page");

			include "app/views/topicBlog.php";
		}
	}
	new topicBlog();

?>