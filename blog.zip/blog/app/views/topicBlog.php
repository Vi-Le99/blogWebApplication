<main class="container">

<div class="nav-scroller py-1 mb-2">
  <nav class="nav d-flex justify-content-between" id="a_hover">
    <a class="p-2 link-secondary" href="index.php" style="text-decoration: none;">Trang chủ</a>
    <?php
          $data = $this->Model->fetch("select * from menu_catalog");
          
          foreach ($data as $value) {
      ?>   
    <a class="p-2 link-secondary" href="index.php?controller=topicBlog&id=<?php echo $value["id"]?>" style="text-decoration: none;"> 
                  <?php
                      echo $value["name"];
                  ?></a>  <?php } ?>
    
    
  </nav>
</div>
<br>

<!--<div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
    <div class="col-md-6 px-0">-->
    <!-- <img src="https://scontent.fvca1-1.fna.fbcdn.net/v/t1.15752-9/132431589_2933227346963826_2374131234119668702_n.png?_nc_cat=102&ccb=2&_nc_sid=ae9488&_nc_ohc=BAAIZvn2YtcAX9__IZm&_nc_ht=scontent.fvca1-1.fna&oh=5244ecd0c894a1410647cd5914dd11ec&oe=600F83C7"> -->
   <!-- <h1 class="display-4 font-italic">Tổng hợp những công thức nấu ăn ngon dành cho bạn</h1>
    <p class="lead my-3">Khơi nguồn xuống bếp!</p>
    <p class="lead mb-0"><a href="#" class="text-white fw-bold">Xem thêm...</a></p>
    </div>
  </div>-->

 
<!-- bắt đầu chủ đề bài post -->
<div class="row mb-2">

        <?php
        
            foreach ($value1 as $gt) {
        ?>   

    <div class="col-md-6">
        <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
                <h3 class="mb-0">
                <?php
                        
                        echo $gt["name"];
                    ?>
                </h3>
                <div class="mb-1 text-muted">-----</div>
                <p class="card-text mb-auto">
                <?php
                        echo '';
                    ?></p>
                <a href="index.php?controller=detailBlog&id=<?php echo $gt["id"]?>" class="stretched-link">Đọc tiếp</a>
            </div>
            <div class="col-auto d-none d-lg-block">
                <img src="<?php echo $gt["avatar"] ?>" alt="" class="bd-placeholder-img card-body" width="260px" height="250px"   >
            </div>
        </div>
    </div>
            
    <?php } ?>
        
            <div class="col-md-12">
                <ul class="pagination">
                   <?php for($i=1; $i<=$page_show; $i++){ ?>
                      <li>
                         <a href="index.php?controller=topicBlog&id=<?php echo $value["id"]-1?>&p=<?php echo $i ?>">
                            <?php echo $i; ?>
                         </a>
                      </li>
                   <?php } ?>
                </ul>               
            </div>
                   
    <!-- 1 dòng -->
</div>

                   

</main><!-- /.container -->

